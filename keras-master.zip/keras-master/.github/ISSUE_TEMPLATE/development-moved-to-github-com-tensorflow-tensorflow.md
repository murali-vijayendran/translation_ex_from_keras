---
name: Development moved to github.com/tensorflow/tensorflow
about: Please file your bug report by creating a new issue in the TensorFlow repository.
title: ''
labels: ''
assignees: ''

---

**Important note:** the development of Keras is currently taking place at [`github.com/tensorflow/tensorflow`](https://github.com/tensorflow/tensorflow). Please file your bug report by creating a new issue in the TensorFlow repository.

Please note that multi-backend Keras development has been discontinued. Do not report issues about multi-backend Keras (Keras 2.3.1 and lower), only report issues about the TensorFlow implementation of Keras (tf.keras).
