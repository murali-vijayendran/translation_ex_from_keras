"""A `Network` is way to compose layers: the topological form of a `Model`."""

from tensorflow.keras import Model as Network
from tensorflow.keras.utils import get_source_inputs
