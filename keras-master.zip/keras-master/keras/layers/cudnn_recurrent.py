"""Recurrent layers backed by cuDNN."""

from tensorflow.keras.layers import GRU as CuDNNGRU
from tensorflow.keras.layers import LSTM as CuDNNLSTM
