"""Embedding layer."""

from tensorflow.keras.layers import Embedding
