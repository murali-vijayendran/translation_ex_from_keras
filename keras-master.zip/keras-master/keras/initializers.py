"""Built-in weight initializers."""

from tensorflow.keras.initializers import *