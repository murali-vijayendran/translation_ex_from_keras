"""Boston housing price regression dataset."""

from tensorflow.keras.datasets.boston_housing import load_data
