"""Fashion-MNIST dataset."""

from tensorflow.keras.datasets.fashion_mnist import load_data
