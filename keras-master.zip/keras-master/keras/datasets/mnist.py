"""MNIST handwritten digits dataset."""

from tensorflow.keras.datasets.mnist import load_data
